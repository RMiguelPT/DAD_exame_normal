import { Component, Input, OnInit } from '@angular/core';
import {WebSocketService } from '../notifications/websocket.service';
import { NewGameComponent } from './../game/newGame.component';
import { GameService } from "./../_services/game.service";


@Component({
    moduleId: module.id,
    selector: 'card',
    templateUrl: 'card.component.html'
    //styleUrls: ['board.component.css']
})
export class CardComponent {
     
   
}