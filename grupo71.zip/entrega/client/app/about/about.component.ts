import { Component } from '@angular/core';
import {Routes, RouterModule } from '@angular/router';

@Component({
    moduleId: module.id,
    selector: 'my-app',
    templateUrl: `about.component.html`
})
export class AboutComponent { }
